#!/bin/bash
######################################## s 7 ###############################################
with() {
    while true; do
        read -p "Enter condition where you want to change : " condn
        if grep -q "$condn" $Dtable; then

            read -p "Enter number of ther PK :hint it must be 1 : " pkcol
            while true; do
                if [ "$pkcol" -eq 1 ]; then
                    break
                else
                    read -p " ya 3m 2olna it must be 1 b2aaa ! !  🥴️ : " pkcol
                fi
            done
            read -p "Enter  thr PK  : " pk
            read -p "Enter condition where you want to set : " rep
            awk -F' ' -v field1="$colln" -v cond1="$condn" -v field2="$pkcol" -v cond2="$pk" -v rep="$rep" '{
    if (NR == 1) {
        print
    } else {
        if ($field1 == cond1 && $field2 == cond2) {
            $field1 = rep
        }
        print
    }
}' $Dtable >temp_$Dtable.txt && mv temp_$Dtable.txt $Dtable
            echo " done yam3lm 😎️"
            break
        else
            echo "Condition not found in table"
            break
        fi
    done
}
without() {

    while true; do
        read -p "Enter condition where you want to change : " condn
        if grep -q "$condn" $Dtable; then
            read -p "Enter condition where you want to set : " rep
            awk -F' ' -v field="$colln" -v cond="$condn" -v rep="$rep" '{
    if (NR == 1) {
        print
    } else {
        if ($field == cond ) {
            $field = rep
        }
        print
    }
}' $Dtable >temp_$Dtable.txt && mv temp_$Dtable.txt $Dtable
            echo " done yam3lm "
            break
        else
            echo "Condition not found in table"
            break
        fi
    done
}

update_data() {
while true ; do 
   
    read -p "Enter name of the table : " Dtable
    # Loop until a valid table name is entered
    while true; do
        if [[ -f "$Dtable" ]]; then
            echo "table exists!"
            break
        else 
            read -p "Enter name of the table again : " Dtable
        fi
    done
    while true; do
    read -p "Enter number of column you want to select by : " colln
        conter=$(awk 'NR==1{print NF}' $Dtable)
                if [[ $colln -le "$conter" && $colln -ge 1 ]]; then
                    break
                fi
            done
    
    read -p "Do you want to update with ID or generally [with/without]? " anse
while true; do
  if [ "$anse" = "with" ]; then
    with
    break
  elif [ "$anse" = "without" ]; then
    without
    break
  else
   read -p "only [with/without] 🙆‍♀️️" anse
  fi
done
    
    break
    done
}
##########################################################################################
Drop_table() {
 while true; do
          read -p "Enter table name: " table

        if [ -f "$table".txt ]; then
          rm "$table".txt
    echo "You deleted the table."
         break
     else
    echo "Directory '$table' does not exist."
     echo "Please enter a name of table correctly."
  fi
done
}
########################################## s6 #############################################
delete_data() {
    read -p "Enter name of the table : " Dtable
    while true; do
        if [[ -f "$Dtable" ]]; then
            echo "table is exist!"
            break
        else
            read -p "Enter name of the table agien : " Dtable
        fi
    done
    read -p "Do you want to delete all data (o1) or specific rows (o2)? : " ans2

    while true; do
        if [[ $ans2 = "o1" ]]; then
            sed '3,$d' $Dtable >temp_$Dtable.txt && mv temp_$Dtable.txt $Dtable
            echo "done 😉️"
            break
        elif [[ $ans2 = "o2" ]]; then
            while true; do
                read -p "Enter number of column you want to select by : " colln

                conter=$(awk 'NR==1{print NF}' $Dtable)
                if [[ $colln -le "$conter" && $colln -ge 1 ]]; then
                    break
                fi
            done
            while true; do
                read -p "Enter condition where you want to select : " condn

                if grep -q "$condn" $Dtable; then

                    awk -v col=$colln -v cond="$condn" 'NR==1 || ($col != cond) {print}' $Dtable >temp_$Dtable.txt && mv temp_$Dtable.txt $Dtable
                   break 
                fi
            done
          break
        else
            read -p "Please only  [o1/o2]: " ans2
        fi
    done
}
####################################### m1 ################################################
create_Database() {
    while true; do
        read -p "Enter database name: " name
        if [[ $name =~ $condition1 || $name =~ $condition2 ]]; then
            echo "Please enter name again without numbers or spaces."
        elif [ ! -d "$name" ]; then
            mkdir "$name"
            echo "You created a new database."
            break
        else
            echo "Directory '$name' already exists."
            echo "Please enter a different name."
        fi
    done
}
######################################### s1 ##############################################
create_table() { 
while true; do
    read -p "Enter Table name: " name4
    while true;do
    if [[ $name4 =~ $condition1 || $name4 =~ $condition2 ]]; then
        read -p "Please enter name again without numbers or spaces." name4
    else
    break
    fi 
    done
        echo " table is created "      
        touch $name4.txt
        echo "note : first column is primary and its datatype must be intger"
        read -p "Enter a name of PK column: " coln
        echo -n "PK" >>$name4.txt
        echo -n "$coln " >>$name4.txt
        count=2
        while true; do
            read -p "Enter [y/n] " ans
            if [[ "$ans" = "y" ]]; then
                count=$((count + 1))
                read -p "Enter another value: " coln
                echo -n "$coln " >>$name4.txt
            elif [[ "$ans" = "n" ]]; then
                break
            else
                echo "Invalid input. Please try again."
            fi
        done
        echo "" >>$name4.txt
        read -p "Enter datatype of PK column: " cold
        while true; do
            if [[ $cold = "integer" ]]; then
                echo -n "$cold " >>$name4.txt
                break
            else
                read -p "It must be integer: " cold
            fi
        done
        for ((i = 2; i < count; i += 1)); do
            read -p "Enter datatype of column: " cold
            while true; do
                if [[ $cold = "string" || $cold = "integer" || $cold = "boolean" ]]; then
                    echo -n "$cold " >>$name4.txt
            
                    break
                else
                    read -p "Enter datatype of column again: " cold
                fi

            done
        done

  
    break
done }
########################################### s5 ############################################
Select_Data() {
    while true; do
        read -p "enter name of table : " table
        if [ -f "$table" ]; then
            break
        else
            echo " this $table dosen;t exit"
        fi
    done
}
select_from_T_where() {
    Dtable=$table
    while true; do
        read -p "Enter the field numbers to print : " fields
        read -p "Enter number of column you want to select by: " coln
        read -p "Enter condition where you want to select: " condn

        awk -v fields="$fields" -v coln="$coln" -v condn="$condn" '
        BEGIN{split(fields, a, 
        ",")}
        {if ($coln == condn) {for (i in a) printf "%-10s ", $a[i]; printf "\n"}}
    ' $Dtable
        break
    done
}


select_all_from_t1_where_cond_1() {
    while true; do
        read -p "enter your condition like $n == word" condition
        awk "${condition} { print  }" $table | column -t
        break
    done
}


########################################## s4 #############################################
insert_data() {

    while true; do
        read -rp "Enter name of table: " table
        if [ ! -f "$table" ];  then
            echo "Table $table doesn't exist or is not readable."
        else
            break
        fi
    done
  
    # Display column names and data types
    sed -n '1p;2p' "$table"
    
    # Count number of columns
    counter=$(awk 'NR==1{print NF}' "$table")
    
    # Loop to prompt user to enter data for each column
    while true; do
        i=1
        while [ $i -le $counter ]; do
            read -rp "Enter data for column $i: " fdata
            coltype=$(awk -v field="$i" 'NR==2{print $field}' "$table")
            if [ $i -eq 1 ]; then
                while ! [[ $fdata =~ ^[0-9]+$ ]]; do
                    read -rp "First field must be an integer. Please enter data again: " fdata
                done
                if [[ "$(cut -d' ' -f1 "$table" | grep -w "^$fdata$")" ]]; then
                    echo "First field cannot be repeated."
                    continue 2
                fi
                  printf "%s " "$fdata" >> "$table"
            elif [ "$coltype" = "string" ]; then
                while ! [[ $fdata =~ ^[a-zA-Z]+$ ]]; do
                    read -rp "Data for column $i is not a string. Please enter data again: " fdata
                done
                printf "%s " "$fdata" >> "$table"
                echo "Data for column $i is valid."
            elif [ "$coltype" = "integer" ]; then
                while ! [[ $fdata =~ ^[0-9]+$ ]]; do
                    read -rp "Data for column $i is not an integer. Please enter data again: " fdata
                done
                printf "%s " "$fdata" >> "$table"
                echo "Data for column $i is valid."
            else
                echo "Unknown data type for column $i."
                break
            fi
            i=$((i+1))
        done
        
        printf "\n" >> "$table"
        echo "Data inserted successfully."
        
        read -rp "Do you want to enter another data [y/n] " Ques
        case "$Ques" in
        y|Y) continue ;;
        n|N) break ;;
        *) echo "Invalid input. Please enter 'y' or 'n'." ;;
        esac
    done
}

############################################ s 3 ###########################################
############################################## m4 ########################################
delete_Database ()
 {

while true; do
  read -p "Enter database name: " name2

  if [ -d "$name2" ]; then
    rmdir "$name2"
    echo "You deleted the database."
    break
  else
    echo "Directory '$name2' does not exist."
    echo "Please enter a different name."
  fi
done
}
######################################################################################
echo "choose number from main menu"
select choice in "create Database" "list Database" "Connect To Database" "Drop Database"; do
    case $REPLY in
    1)
        echo "create Database"
        condition1="[0-9]"
        condition2=" "
        create_Database
        ;;
    2)
        echo "list Database"
        ls -d */
        ;;

    3)
        echo "Connecting to a database..."
        read -p "Enter name of database: " database_name
        while true; do
            if [ ! -d "$database_name" ]; then
                echo "Database not found. Please enter the name again."
                read -p "Enter name of database: " database_name
            else
                cd "$database_name"
                echo "Connected to database: $PWD"
                echo "Choose an option: "
                select ch2 in "Create a table" "List tables" "Drop a table" "Insert data" "Select data" "Delete data" "Update data" "back" ; do
                    case $REPLY in
                    1)
                        echo "create_table"
                        condition1="[0-9]"
                        condition2=" "
                        create_table
                        ;;
                    2)
                        echo "list_tables"
                        if [ -f $table ]; then
                        ls -1 | grep '\.txt$'
                        fi
                        ;;
                    3)
                        echo "drop_table"
                      Drop_table
                        ;;
                    4)
                        echo "insert_data"

                        insert_data

                        ;;

                    5)
                        echo "select_data"
                        Select_Data

                        select choice3 in "select * from T " "select col1,3,5 from T where ..." "select * from t1 where  " "select 1,3,5 from t1 " "back" ; do
                            case $REPLY in
                                
                            1)echo "select * from T "
                                column -t  $table
                                ;;
                            2)
                                echo "select col1,3,5 from T where ...."
                                select_from_T_where
                                ;;
                            
                            3)
                                echo "select * from t1 where .."
                                select_all_from_t1_where_cond_1
                                ;;
                            4)
                                echo "select 1,3,5 from t1"
                                read -p "enter number of field " field
                                cut -d" " -f"$field" $table | column -t
                                ;;
                            5) echo "back to sm"
                                break
                                ;;
                            *)
                                "invalid input"
                                ;;

                            esac
                        done



                        ;;
                    6)
                        echo "delete_data"
                        delete_data
                        ;;
                    7)
                        echo "update_data"
                        update_data
                        ;;
                    8)
                        echo "back to mm."
                        cd ..
                        echo "u are in mm now"
                        break 2
                        
                        ;;
                        * ) 
                        echo "Invalid option. Please try again."
                       
                        ;;
                    esac
                    
                done

                break
            fi
        done
        ;;

    4)
        echo "delete Database"
        delete_Database
        ;;
    esac
done





